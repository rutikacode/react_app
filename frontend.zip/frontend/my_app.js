import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectTrigger, SelectContent, SelectItem } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

const optionsList = ["Option 1", "Option 2", "Option 3", "Option 4"];

const TableComponent = () => {
  const [rows, setRows] = useState([{ id: 1, label1: "", label2: [] }]);
  const [availableOptions, setAvailableOptions] = useState(optionsList);
  const [newOption, setNewOption] = useState("");

  const handleAddRow = () => {
    setRows([...rows, { id: rows.length + 1, label1: "", label2: [] }]);
  };

  const handleAddNewOption = () => {
    if (newOption.trim() !== "" && !availableOptions.includes(newOption)) {
      setAvailableOptions([...availableOptions, newOption]);
      setNewOption("");
    }
  };

  return (
    <div className="p-5">
      <Card className="p-5">
        <CardContent>
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr>
                <th className="border p-2">Label 1</th>
                <th className="border p-2">Label 2</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={row.id} className="border">
                  <td className="border p-2">
                    <Select onValueChange={(value) => {
                      const newRows = [...rows];
                      newRows[index].label1 = value;
                      setRows(newRows);
                    }}>
                      <SelectTrigger>{row.label1 || "Select Option"}</SelectTrigger>
                      <SelectContent>
                        {availableOptions.map((option) => (
                          <SelectItem key={option} value={option} disabled={rows.some(r => r.label1 === option)}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="border p-2">
                    <div className="flex gap-2 flex-wrap border p-2 rounded">
                      {row.label2.map((opt, i) => (
                        <span key={i} className="bg-gray-200 px-2 py-1 rounded">
                          {opt}
                        </span>
                      ))}
                      <Select onValueChange={(value) => {
                        const newRows = [...rows];
                        if (!newRows[index].label2.includes(value)) {
                          newRows[index].label2.push(value);
                          setRows(newRows);
                        }
                      }}>
                        <SelectTrigger>Select Options</SelectTrigger>
                        <SelectContent>
                          {availableOptions.map((option) => (
                            <SelectItem key={option} value={option}>{option}</SelectItem>
                          ))}
                          <div className="flex items-center p-2 border-t">
                            <Input
                              type="text"
                              value={newOption}
                              onChange={(e) => setNewOption(e.target.value)}
                              placeholder="Add new item"
                              className="mr-2"
                            />
                            <Button onClick={handleAddNewOption}>Add</Button>
                          </div>
                        </SelectContent>
                      </Select>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <Button className="mt-4" onClick={handleAddRow}>+ Add New Row</Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default TableComponent;
