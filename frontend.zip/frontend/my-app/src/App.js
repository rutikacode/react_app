import logo from './logo.svg';
import './App.css';
import TableComponent from './TableComponent';

function App() {
  return (
   <>
   <TableComponent/>
   </>
  );
}

export default App;