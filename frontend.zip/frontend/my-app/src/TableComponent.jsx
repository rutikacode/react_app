import React, { useState } from "react";
import {
  Button,
  Card,
  CardContent,
  Checkbox,
  FormControlLabel,
  Select,
  MenuItem,
  TextField,
  Chip,
} from "@mui/material";

const optionsList = ["Option 1", "Option 2", "Option 3", "Option 4"];

const TableComponent = () => {
  const [rows, setRows] = useState([{ id: 1, label1: "", label2: [] }]);
  const [availableOptions, setAvailableOptions] = useState(optionsList);
  const [newOption, setNewOption] = useState("");

  const handleAddRow = () => {
    setRows([...rows, { id: rows.length + 1, label1: "", label2: [] }]);
  };

  const handleAddNewOption = () => {
    if (newOption.trim() !== "" && !availableOptions.includes(newOption)) {
      setAvailableOptions([...availableOptions, newOption]);
      setNewOption("");
    }
  };

  return (
    <div className="p-5">
      <Card sx={{ padding: 3 }}>
        <CardContent>
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr>
                <th className="border p-2">Label 1</th>
                <th className="border p-2">Label 2</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={row.id} className="border">
                  <td className="border p-2">
                    <Select
                      value={row.label1}
                      onChange={(e) => {
                        const newRows = [...rows];
                        newRows[index].label1 = e.target.value;
                        setRows(newRows);
                      }}
                      fullWidth
                    >
                      <MenuItem value="" disabled>
                        Select Option
                      </MenuItem>
                      {availableOptions.map((option) => (
                        <MenuItem
                          key={option}
                          value={option}
                          disabled={rows.some((r) => r.label1 === option)}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Select>
                  </td>
                  <td className="border p-2">
                    <div className="flex gap-2 flex-wrap border p-2 rounded">
                      {row.label2.map((opt, i) => (
                        <Chip
                          key={i}
                          label={opt}
                          color="primary"
                          size="small"
                        />
                      ))}
                      <Select
                        value=""
                        onChange={(e) => {
                          const value = e.target.value;
                          const newRows = [...rows];
                          if (!newRows[index].label2.includes(value)) {
                            newRows[index].label2.push(value);
                            setRows(newRows);
                          }
                        }}
                        displayEmpty
                        fullWidth
                      >
                        <MenuItem value="" disabled>
                          Select Options
                        </MenuItem>
                        {availableOptions.map((option) => (
                          <MenuItem key={option} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                    </div>
                    {/* Add new option input */}
                    <div className="flex items-center p-2 border-t">
                      <TextField
                        label="Add new item"
                        type="text"
                        value={newOption}
                        onChange={(e) => setNewOption(e.target.value)}
                        variant="outlined"
                        size="small"
                        fullWidth
                        sx={{ marginRight: 2 }}
                      />
                      <Button variant="contained" onClick={handleAddNewOption}>
                        Add
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <Button
            className="mt-4"
            variant="contained"
            color="primary"
            onClick={handleAddRow}
          >
            + Add New Row
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default TableComponent;